package dev.oblostic;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class Oblostic implements ClientModInitializer {
    public static KeyBinding menuKey, zoomKey;

    @Override
    public void onInitializeClient() {
        Config.load();
        Modules.init();

        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.oblostic.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.oblostic"));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.oblostic.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.oblostic"));

        ClientTickEvents.END_CLIENT_TICK.register(Oblostic::tick);
        HudRenderCallback.EVENT.register(Hud::render);
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> {
            Effects.restore(mc);
            Config.save();
        });
    }

    private static void tick(MinecraftClient mc) {
        while (menuKey.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new SettingsScreen(null));
        }
        Effects.tick(mc);
    }
}
