package dev.oblostic;

import net.minecraft.client.MinecraftClient;

/** Zoom and max-brightness, using only vanilla options. Restored automatically. */
public class Effects {
    private static Integer savedFov = null;
    private static Double savedGamma = null;

    public static void tick(MinecraftClient mc) {
        boolean zooming = Config.get().zoom && Oblostic.zoomKey.isPressed() && mc.currentScreen == null;
        if (zooming && savedFov == null) {
            savedFov = mc.options.getFov().getValue();
            mc.options.getFov().setValue(30);
        } else if (!zooming && savedFov != null) {
            mc.options.getFov().setValue(savedFov);
            savedFov = null;
        }

        boolean bright = Config.get().maxBrightness;
        if (bright && savedGamma == null) {
            savedGamma = mc.options.getGamma().getValue();
            mc.options.getGamma().setValue(1.0);
        } else if (!bright && savedGamma != null) {
            mc.options.getGamma().setValue(savedGamma);
            savedGamma = null;
        }
    }

    public static void restore(MinecraftClient mc) {
        if (savedFov != null) { mc.options.getFov().setValue(savedFov); savedFov = null; }
        if (savedGamma != null) { mc.options.getGamma().setValue(savedGamma); savedGamma = null; }
    }
}
