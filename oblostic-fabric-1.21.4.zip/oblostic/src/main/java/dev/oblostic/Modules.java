package dev.oblostic;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class Modules {
    public static final List<Module> ALL = new ArrayList<>();

    public static void init() {
        ALL.add(new TextModule("fps", "FPS", 4, 4,
                mc -> List.of("FPS: " + mc.getCurrentFps())));
        ALL.add(new TextModule("cps", "CPS", 4, 22,
                mc -> List.of("CPS: " + Cps.left() + " | " + Cps.right())));
        ALL.add(new TextModule("ping", "Ping", 4, 40, mc -> {
            if (mc.player == null || mc.getNetworkHandler() == null) return List.of();
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            return List.of("Ping: " + (e == null ? 0 : e.getLatency()) + " ms");
        }));
        ALL.add(new TextModule("coords", "Coordinates", 4, 58, mc -> {
            if (mc.player == null) return List.of();
            return List.of(String.format("XYZ: %.1f %.1f %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ()),
                    "Facing: " + mc.player.getHorizontalFacing().asString());
        }));
        ALL.add(new TextModule("state", "Movement State", 4, 82, mc -> {
            if (mc.player == null) return List.of();
            String s = mc.player.isSneaking() ? "Sneaking" : mc.player.isSprinting() ? "Sprinting" : "Walking";
            return List.of(s);
        }));
        ALL.add(new TextModule("effects", "Potion Effects", 100, 4, mc -> {
            List<String> out = new ArrayList<>();
            if (mc.player == null) return out;
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                int sec = e.getDuration() / 20;
                out.add(e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1)
                        + " (" + (sec / 60) + ":" + String.format("%02d", sec % 60) + ")");
            }
            return out;
        }));
        ALL.add(new Keystrokes());
        ALL.add(new Armor());
    }

    // ---------- Text based module ----------
    static class TextModule extends Module {
        final Function<MinecraftClient, List<String>> lines;

        TextModule(String id, String name, int x, int y, Function<MinecraftClient, List<String>> lines) {
            super(id, name, x, y);
            this.lines = lines;
        }

        public int width(MinecraftClient mc) {
            List<String> l = lines.apply(mc);
            if (l.isEmpty()) return mc.textRenderer.getWidth(name) + 8;
            int w = 0;
            for (String s : l) w = Math.max(w, mc.textRenderer.getWidth(s));
            return w + 8;
        }

        public int height(MinecraftClient mc) {
            List<String> l = lines.apply(mc);
            return (l.isEmpty() ? 1 : l.size()) * 10 + 6;
        }

        public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean editing) {
            List<String> l = lines.apply(mc);
            if (l.isEmpty()) {
                if (!editing) return;
                l = List.of(name);
            }
            c.fill(x, y, x + width(mc), y + height(mc), 0x90000000);
            int ty = y + 4;
            for (String s : l) {
                c.drawText(mc.textRenderer, s, x + 4, ty, 0xFFFFFFFF, true);
                ty += 10;
            }
        }
    }

    // ---------- Keystrokes ----------
    static class Keystrokes extends Module {
        Keystrokes() { super("keystrokes", "Keystrokes", 4, 110); }

        public int width(MinecraftClient mc) { return 70; }
        public int height(MinecraftClient mc) { return 86; }

        public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean editing) {
            var o = mc.options;
            key(c, mc, "W", null, x + 24, y, 22, 22, o.forwardKey.isPressed());
            key(c, mc, "A", null, x, y + 24, 22, 22, o.leftKey.isPressed());
            key(c, mc, "S", null, x + 24, y + 24, 22, 22, o.backKey.isPressed());
            key(c, mc, "D", null, x + 48, y + 24, 22, 22, o.rightKey.isPressed());
            key(c, mc, "LMB", String.valueOf(Cps.left()), x, y + 48, 34, 22, o.attackKey.isPressed());
            key(c, mc, "RMB", String.valueOf(Cps.right()), x + 36, y + 48, 34, 22, o.useKey.isPressed());
            key(c, mc, "SPACE", null, x, y + 72, 70, 14, o.jumpKey.isPressed());
        }

        static void key(DrawContext c, MinecraftClient mc, String label, String sub,
                        int x, int y, int w, int h, boolean down) {
            c.fill(x, y, x + w, y + h, down ? 0xAAFFFFFF : 0x90000000);
            int col = down ? 0xFF000000 : 0xFFFFFFFF;
            var tr = mc.textRenderer;
            if (sub == null) {
                c.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2, col, false);
            } else {
                c.drawText(tr, label, x + (w - tr.getWidth(label)) / 2, y + 3, col, false);
                c.drawText(tr, sub, x + (w - tr.getWidth(sub)) / 2, y + 12, col, false);
            }
        }
    }

    // ---------- Armor status ----------
    static class Armor extends Module {
        static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST,
                EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND};

        Armor() { super("armor", "Armor Status", 100, 60); }

        public int width(MinecraftClient mc) { return 64; }
        public int height(MinecraftClient mc) { return SLOTS.length * 18; }

        public void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean editing) {
            if (mc.player == null) return;
            int cy = y;
            for (EquipmentSlot slot : SLOTS) {
                ItemStack s = mc.player.getEquippedStack(slot);
                if (!s.isEmpty()) {
                    c.drawItem(s, x, cy);
                    c.drawStackOverlay(mc.textRenderer, s, x, cy);
                    if (s.isDamageable()) {
                        c.drawText(mc.textRenderer, String.valueOf(s.getMaxDamage() - s.getDamage()),
                                x + 20, cy + 5, 0xFFFFFFFF, true);
                    }
                } else if (editing) {
                    c.fill(x, cy, x + 16, cy + 16, 0x50FFFFFF);
                }
                cy += 18;
            }
        }
    }
}
