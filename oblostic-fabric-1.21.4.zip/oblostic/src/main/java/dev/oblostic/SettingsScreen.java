package dev.oblostic;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class SettingsScreen extends Screen {
    private final Screen parent;

    public SettingsScreen(Screen parent) {
        super(Text.literal("Oblostic"));
        this.parent = parent;
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    protected void init() {
        int bw = 150, bh = 20, gap = 4;
        int startX = width / 2 - bw - gap / 2;
        int y0 = 34;
        int i = 0;
        for (Module m : Modules.ALL) {
            int x = startX + (i % 2) * (bw + gap);
            int y = y0 + (i / 2) * (bh + gap);
            addDrawableChild(ButtonWidget.builder(label(m.name, m.enabled()), b -> {
                m.st().enabled = !m.st().enabled;
                b.setMessage(label(m.name, m.enabled()));
            }).dimensions(x, y, bw, bh).build());
            i++;
        }
        int y = y0 + ((i + 1) / 2) * (bh + gap) + 6;

        addDrawableChild(ButtonWidget.builder(label("Zoom (C)", Config.get().zoom), b -> {
            Config.get().zoom = !Config.get().zoom;
            b.setMessage(label("Zoom (C)", Config.get().zoom));
        }).dimensions(startX, y, bw, bh).build());

        addDrawableChild(ButtonWidget.builder(label("Max Brightness", Config.get().maxBrightness), b -> {
            Config.get().maxBrightness = !Config.get().maxBrightness;
            b.setMessage(label("Max Brightness", Config.get().maxBrightness));
        }).dimensions(startX + bw + gap, y, bw, bh).build());

        y += bh + gap;
        addDrawableChild(ButtonWidget.builder(Text.literal("Edit HUD Layout"),
                b -> client.setScreen(new EditScreen(this)))
                .dimensions(startX, y, bw * 2 + gap, bh).build());

        y += bh + gap;
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(startX, y, bw * 2 + gap, bh).build());
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        c.drawCenteredTextWithShadow(textRenderer, "OBLOSTIC CLIENT", width / 2, 14, 0xFF55FFFF);
    }

    @Override
    public void removed() { Config.save(); }

    @Override
    public void close() { client.setScreen(parent); }
}
