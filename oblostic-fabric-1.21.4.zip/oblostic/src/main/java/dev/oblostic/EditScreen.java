package dev.oblostic;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class EditScreen extends Screen {
    private final Screen parent;
    private Module dragging;
    private int offX, offY;

    public EditScreen(Screen parent) {
        super(Text.literal("Edit HUD Layout"));
        this.parent = parent;
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        super.render(c, mx, my, delta);
        Hud.renderAll(c, client, true);
        for (Module m : Modules.ALL) {
            if (!m.enabled()) continue;
            Config.ModState s = m.st();
            c.drawBorder(s.x - 1, s.y - 1, m.width(client) + 2, m.height(client) + 2,
                    m == dragging ? 0xFF55FF55 : 0xFF55FFFF);
        }
        c.drawCenteredTextWithShadow(textRenderer, "Drag modules to move them. Press Esc to save.", width / 2, 6, 0xFFFFFFFF);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (int i = Modules.ALL.size() - 1; i >= 0; i--) {
            Module m = Modules.ALL.get(i);
            if (!m.enabled()) continue;
            Config.ModState s = m.st();
            if (mx >= s.x && mx <= s.x + m.width(client) && my >= s.y && my <= s.y + m.height(client)) {
                dragging = m;
                offX = (int) mx - s.x;
                offY = (int) my - s.y;
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            Config.ModState s = dragging.st();
            s.x = Hud.clamp((int) mx - offX, width - dragging.width(client));
            s.y = Hud.clamp((int) my - offY, height - dragging.height(client));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragging = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public void removed() { Config.save(); }

    @Override
    public void close() { client.setScreen(parent); }
}
