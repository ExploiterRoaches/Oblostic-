package dev.oblostic;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public class Hud {
    public static void render(DrawContext c, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden || mc.currentScreen instanceof EditScreen) return;
        renderAll(c, mc, false);
    }

    public static void renderAll(DrawContext c, MinecraftClient mc, boolean editing) {
        for (Module m : Modules.ALL) {
            if (!m.enabled()) continue;
            Config.ModState s = m.st();
            int x = clamp(s.x, mc.getWindow().getScaledWidth() - m.width(mc));
            int y = clamp(s.y, mc.getWindow().getScaledHeight() - m.height(mc));
            m.draw(c, mc, x, y, editing);
        }
    }

    public static int clamp(int v, int max) { return Math.max(0, Math.min(v, Math.max(0, max))); }
}
