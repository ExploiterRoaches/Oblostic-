package dev.oblostic;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class Config {
    public static class ModState {
        public boolean enabled = true;
        public int x, y;
    }

    public Map<String, ModState> modules = new HashMap<>();
    public boolean zoom = true;
    public boolean maxBrightness = false;

    private static Config instance = new Config();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("oblostic.json");

    public static Config get() { return instance; }

    public static ModState state(String id, int dx, int dy) {
        return instance.modules.computeIfAbsent(id, k -> {
            ModState s = new ModState();
            s.x = dx;
            s.y = dy;
            return s;
        });
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                Config c = GSON.fromJson(Files.readString(FILE), Config.class);
                if (c != null) instance = c;
            }
        } catch (Exception e) {
            System.err.println("[Oblostic] Failed to load config: " + e);
        }
    }

    public static void save() {
        try {
            Files.writeString(FILE, GSON.toJson(instance));
        } catch (Exception e) {
            System.err.println("[Oblostic] Failed to save config: " + e);
        }
    }
}
