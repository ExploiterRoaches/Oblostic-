package dev.oblostic;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

public abstract class Module {
    public final String id, name;
    private final int dx, dy;

    protected Module(String id, String name, int dx, int dy) {
        this.id = id;
        this.name = name;
        this.dx = dx;
        this.dy = dy;
    }

    public Config.ModState st() { return Config.state(id, dx, dy); }
    public boolean enabled() { return st().enabled; }

    public abstract int width(MinecraftClient mc);
    public abstract int height(MinecraftClient mc);
    public abstract void draw(DrawContext c, MinecraftClient mc, int x, int y, boolean editing);
}
