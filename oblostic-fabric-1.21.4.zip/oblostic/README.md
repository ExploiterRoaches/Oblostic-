# Oblostic Client (Fabric, Minecraft 1.21.4)

Server-safe HUD + QoL mod: FPS, CPS, Keystrokes, Ping, Coordinates, Movement State,
Armor Status, Potion Effects, Zoom (hold C), Max Brightness, and a drag-and-drop HUD editor.
No combat/cheat features.

## Build
Requires JDK 21 and Gradle 8.12+.

    gradle build

Jar appears in build/libs/oblostic-1.0.0.jar (not the -sources jar).
Drop it in your .minecraft/mods folder with Fabric Loader 0.16.10+ and Fabric API for 1.21.4.
For best FPS also install Sodium, Lithium and Iris.

Or open this folder in IntelliJ IDEA and import as a Gradle project.

## Use
- Right Shift: open the Oblostic menu (toggle modules, edit layout)
- C (hold): zoom
- Config saved to .minecraft/config/oblostic.json
